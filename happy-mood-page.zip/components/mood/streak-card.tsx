"use client"

import { motion } from 'framer-motion'
import { Card } from '@/components/ui/card'
import { Flame, Calendar, Trophy, Target, TrendingUp, Star } from 'lucide-react'

interface StreakCardProps {
  streakDays: number
  totalCheckins: number
  longestStreak?: number
}

export function StreakCard({ streakDays, totalCheckins, longestStreak = 0 }: StreakCardProps) {
  const milestones = [7, 14, 30, 60, 90, 180, 365]
  const nextMilestone = milestones.find(m => m > streakDays) || 365
  const progress = (streakDays / nextMilestone) * 100

  const getStreakMessage = () => {
    if (streakDays === 0) return "Start your streak today!"
    if (streakDays < 7) return "Building momentum!"
    if (streakDays < 14) return "One week strong!"
    if (streakDays < 30) return "Two weeks champion!"
    if (streakDays < 60) return "One month warrior!"
    if (streakDays < 90) return "Consistency king/queen!"
    return "Legendary dedication!"
  }

  const getStreakColor = () => {
    if (streakDays < 7) return "text-primary"
    if (streakDays < 30) return "text-accent"
    return "text-secondary"
  }

  return (
    <Card className="p-6 bg-gradient-to-br from-card to-muted/20 overflow-hidden relative">
      {/* Background decoration */}
      <div className="absolute -top-10 -right-10 w-40 h-40 bg-primary/5 rounded-full" />
      <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-secondary/5 rounded-full" />
      
      <div className="relative">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-semibold text-foreground flex items-center gap-2">
            <Flame className="w-5 h-5 text-primary" />
            Your Streak
          </h3>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Calendar className="w-3 h-3" />
            Daily Check-in
          </div>
        </div>

        {/* Main streak display */}
        <div className="text-center mb-6">
          <motion.div
            initial={{ scale: 0.5, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ type: "spring", stiffness: 200 }}
            className="relative inline-block"
          >
            <div className={`text-6xl font-bold ${getStreakColor()}`}>
              {streakDays}
            </div>
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 3 }}
              className="absolute -top-2 -right-4"
            >
              <Flame className="w-8 h-8 text-primary" />
            </motion.div>
          </motion.div>
          <p className="text-sm text-muted-foreground mt-1">day streak</p>
          <p className="text-sm font-medium text-foreground mt-2">{getStreakMessage()}</p>
        </div>

        {/* Progress to next milestone */}
        <div className="mb-6">
          <div className="flex justify-between text-xs text-muted-foreground mb-2">
            <span>Progress to {nextMilestone} days</span>
            <span>{streakDays}/{nextMilestone}</span>
          </div>
          <div className="h-2 bg-muted rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="h-full bg-gradient-to-r from-primary to-secondary rounded-full"
            />
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center p-3 bg-muted/50 rounded-lg">
            <Trophy className="w-5 h-5 text-primary mx-auto mb-1" />
            <div className="font-bold text-foreground">{longestStreak || streakDays}</div>
            <div className="text-xs text-muted-foreground">Best Streak</div>
          </div>
          <div className="text-center p-3 bg-muted/50 rounded-lg">
            <Target className="w-5 h-5 text-secondary mx-auto mb-1" />
            <div className="font-bold text-foreground">{totalCheckins}</div>
            <div className="text-xs text-muted-foreground">Check-ins</div>
          </div>
          <div className="text-center p-3 bg-muted/50 rounded-lg">
            <Star className="w-5 h-5 text-accent mx-auto mb-1" />
            <div className="font-bold text-foreground">{Math.floor(totalCheckins / 7)}</div>
            <div className="text-xs text-muted-foreground">Perfect Weeks</div>
          </div>
        </div>

        {/* Achievements */}
        {streakDays >= 7 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-4 p-3 bg-primary/10 rounded-lg flex items-center gap-3"
          >
            <div className="w-10 h-10 bg-primary/20 rounded-full flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">Achievement Unlocked!</p>
              <p className="text-xs text-muted-foreground">
                {streakDays >= 30 ? "Monthly Master" : streakDays >= 14 ? "Two Week Warrior" : "Week Champion"}
              </p>
            </div>
          </motion.div>
        )}
      </div>
    </Card>
  )
}
