"use client"

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Calendar, Star, Clock, MessageCircle, CheckCircle, Shield } from 'lucide-react'
import { Counselor } from '@/lib/types'
import Link from 'next/link'

interface CounselorCardProps {
  counselor: Counselor
  onSchedule: (counselorId: string) => void
}

export function CounselorCard({ counselor, onSchedule }: CounselorCardProps) {
  return (
    <Card className="p-6 hover:shadow-lg transition-all">
      <div className="flex items-start gap-4">
        <Avatar className="w-16 h-16">
          <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${counselor.id}`} />
          <AvatarFallback>{counselor.full_name.slice(0, 2).toUpperCase()}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="font-semibold text-foreground">{counselor.full_name}</h3>
            {counselor.is_verified && (
              <Badge variant="secondary" className="gap-1">
                <Shield className="w-3 h-3" /> Verified
              </Badge>
            )}
          </div>
          <p className="text-sm text-muted-foreground mb-2">{counselor.field_of_study}</p>
          <p className="text-xs text-muted-foreground mb-3">{counselor.workplace}</p>
          
          <div className="flex flex-wrap gap-2 mb-3">
            {counselor.specializations.slice(0, 3).map((spec, i) => (
              <Badge key={i} variant="outline" className="text-xs">
                {spec}
              </Badge>
            ))}
          </div>

          <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
            <span className="flex items-center gap-1">
              <Star className="w-4 h-4 text-primary fill-primary" />
              {counselor.rating.toFixed(1)}
            </span>
            <span className="flex items-center gap-1">
              <MessageCircle className="w-4 h-4" />
              {counselor.total_sessions} sessions
            </span>
            <span className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              {counselor.experience_years}y exp
            </span>
          </div>

          <Button onClick={() => onSchedule(counselor.id)} className="w-full gap-2">
            <Calendar className="w-4 h-4" /> Schedule Session
          </Button>
        </div>
      </div>
    </Card>
  )
}

interface CounselorListProps {
  mood: 'happy' | 'stressed' | 'lonely'
}

const SAMPLE_COUNSELORS: Counselor[] = [
  {
    id: '1',
    user_id: 'u1',
    full_name: 'Dr. Sarah Chen',
    email: 'sarah@example.com',
    education_level: 'PhD',
    field_of_study: 'Clinical Psychology',
    workplace: 'Wellness Center',
    experience_years: 8,
    why_counsel: 'I believe everyone deserves support',
    certifications: ['Licensed Clinical Psychologist', 'CBT Certified'],
    certificate_urls: [],
    specializations: ['Anxiety', 'Stress Management', 'Work-Life Balance'],
    availability: [{ day: 'monday', start_time: '09:00', end_time: '17:00' }],
    is_verified: true,
    is_active: true,
    rating: 4.9,
    total_sessions: 234,
    created_at: new Date().toISOString()
  },
  {
    id: '2',
    user_id: 'u2',
    full_name: 'Michael Roberts',
    email: 'michael@example.com',
    education_level: 'Masters',
    field_of_study: 'Counseling Psychology',
    workplace: 'Community Health Center',
    experience_years: 5,
    why_counsel: 'Mental health is a journey we take together',
    certifications: ['Licensed Counselor', 'Trauma-Informed Care'],
    certificate_urls: [],
    specializations: ['Depression', 'Loneliness', 'Life Transitions'],
    availability: [{ day: 'tuesday', start_time: '10:00', end_time: '18:00' }],
    is_verified: true,
    is_active: true,
    rating: 4.8,
    total_sessions: 189,
    created_at: new Date().toISOString()
  },
  {
    id: '3',
    user_id: 'u3',
    full_name: 'Dr. Emily Watson',
    email: 'emily@example.com',
    education_level: 'PhD',
    field_of_study: 'Behavioral Health',
    workplace: 'Private Practice',
    experience_years: 12,
    why_counsel: 'Helping others find their path to wellness',
    certifications: ['Licensed Psychologist', 'Mindfulness Instructor'],
    certificate_urls: [],
    specializations: ['Mindfulness', 'Digital Wellness', 'Burnout'],
    availability: [{ day: 'wednesday', start_time: '08:00', end_time: '16:00' }],
    is_verified: true,
    is_active: true,
    rating: 4.95,
    total_sessions: 412,
    created_at: new Date().toISOString()
  }
]

export function CounselorList({ mood }: CounselorListProps) {
  const [schedulingId, setSchedulingId] = useState<string | null>(null)

  const handleSchedule = (counselorId: string) => {
    setSchedulingId(counselorId)
    // In real app, this would open a scheduling modal
  }

  const moodMessages = {
    happy: "Connect with a counselor to maintain your positive momentum",
    stressed: "Our counselors specialize in stress management and can help you find balance",
    lonely: "You don't have to feel alone. Connect with someone who cares"
  }

  return (
    <section className="py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-foreground mb-1">Available Counselors</h2>
          <p className="text-muted-foreground">{moodMessages[mood]}</p>
        </div>
        <Button variant="outline" asChild>
          <Link href="/counselors">View All</Link>
        </Button>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {SAMPLE_COUNSELORS.map((counselor, i) => (
          <motion.div
            key={counselor.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <CounselorCard counselor={counselor} onSchedule={handleSchedule} />
          </motion.div>
        ))}
      </div>

      {/* Scheduling Modal would go here */}
      {schedulingId && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 bg-foreground/50 flex items-center justify-center z-50 p-4"
          onClick={() => setSchedulingId(null)}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            onClick={(e) => e.stopPropagation()}
          >
            <Card className="p-6 max-w-md w-full">
              <div className="text-center">
                <CheckCircle className="w-12 h-12 text-secondary mx-auto mb-4" />
                <h3 className="text-xl font-bold text-foreground mb-2">Request Sent!</h3>
                <p className="text-muted-foreground mb-4">
                  The counselor will review your request and get back to you within 24 hours.
                </p>
                <Button onClick={() => setSchedulingId(null)}>Got it</Button>
              </div>
            </Card>
          </motion.div>
        </motion.div>
      )}
    </section>
  )
}
