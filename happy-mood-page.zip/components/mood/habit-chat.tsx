"use client"

import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { Send, Sparkles } from 'lucide-react'
import { ChatMessage, UserHabit } from '@/lib/types'

interface HabitChatProps {
  habits: UserHabit[]
  userName: string
  mood: 'happy' | 'stressed' | 'lonely'
}

export function HabitChat({ habits, userName, mood }: HabitChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [currentHabitIndex, setCurrentHabitIndex] = useState(0)
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const moodConfig = {
    happy: {
      greeting: `Hey ${userName}! You seem to be doing great today!`,
      followUp: "That's wonderful to hear!",
      color: "primary"
    },
    stressed: {
      greeting: `Hey ${userName}, I noticed you might be having a tough day. Let's talk about it.`,
      followUp: "It's okay to feel this way. Let's work through it together.",
      color: "accent"
    },
    lonely: {
      greeting: `Hi ${userName}, I'm here for you. How are you feeling right now?`,
      followUp: "Thank you for sharing that with me.",
      color: "secondary"
    }
  }

  const config = moodConfig[mood]

  useEffect(() => {
    // Initial greeting
    setTimeout(() => {
      addAssistantMessage(config.greeting)
      setTimeout(() => askAboutHabit(), 2000)
    }, 500)
  }, [])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const addAssistantMessage = (content: string) => {
    setIsTyping(true)
    setTimeout(() => {
      setMessages(prev => [...prev, {
        id: crypto.randomUUID(),
        role: 'assistant',
        content,
        timestamp: new Date().toISOString()
      }])
      setIsTyping(false)
    }, 1000)
  }

  const askAboutHabit = () => {
    if (currentHabitIndex < habits.length) {
      const habit = habits[currentHabitIndex]
      const questions = getHabitQuestion(habit, mood)
      addAssistantMessage(questions)
    } else {
      addAssistantMessage(getClosingMessage(mood))
    }
  }

  const getHabitQuestion = (habit: UserHabit, mood: string) => {
    const happyQuestions: Record<string, string> = {
      reading: `Did you get some reading time today? What are you currently reading?`,
      exercise: `Did you get your workout in today? How did it feel?`,
      meditation: `Have you taken time to meditate today? Even a few minutes counts!`,
      walking: `Did you go for a walk today? Sometimes the best ideas come during walks.`,
      socializing: `Did you connect with anyone today? How was it?`,
      cooking: `Did you cook anything today? What did you make?`,
      music: `Have you played any music today? What's been on your playlist?`,
      journaling: `Did you journal today? What's on your mind?`,
      gaming: `Did you play any games today? Having fun is important!`,
      coding: `Did you write any code today? What are you working on?`,
      art: `Did you create any art today? I'd love to hear about it!`,
      yoga: `Did you do yoga today? How does your body feel?`,
    }

    const stressedQuestions: Record<string, string> = {
      reading: `Have you had a chance to read today? Sometimes getting lost in a book can help.`,
      exercise: `Were you able to move your body today? Even a short walk can help reduce stress.`,
      meditation: `Have you tried some breathing exercises today? It might help calm things down.`,
      walking: `A walk might help clear your mind. Have you been outside today?`,
      socializing: `Have you talked to someone you trust today? Sharing can lighten the load.`,
      cooking: `Making something simple to eat can be grounding. Have you eaten well today?`,
      music: `Music can really help with stress. Have you listened to anything calming?`,
      journaling: `Writing down your thoughts might help. Would you like to share what's bothering you?`,
      gaming: `Sometimes a distraction helps. Have you done anything to take your mind off things?`,
      coding: `If coding helps you focus, that's great. Are you working on something?`,
      art: `Creating something can be therapeutic. Have you tried drawing or creating today?`,
      yoga: `Stretching might help release some tension. Have you tried any yoga today?`,
    }

    const lonelyQuestions: Record<string, string> = {
      reading: `Have you been reading anything? Books can be great companions.`,
      exercise: `Moving your body releases endorphins. Have you been active today?`,
      meditation: `Taking time for yourself is important. Have you meditated today?`,
      walking: `Have you been outside today? Fresh air can lift the spirits.`,
      socializing: `Have you reached out to anyone today? Even a text message counts.`,
      cooking: `Cooking for yourself is an act of self-care. Have you made anything today?`,
      music: `Music can fill the silence. What have you been listening to?`,
      journaling: `Writing can help process feelings. Would you like to share your thoughts?`,
      gaming: `Online games can be a way to connect with others. Have you played today?`,
      coding: `Working on projects can give a sense of purpose. Are you building anything?`,
      art: `Creating art is a beautiful way to express yourself. Have you created anything?`,
      yoga: `Yoga can help you feel more connected to yourself. Have you practiced today?`,
    }

    const questions = mood === 'happy' ? happyQuestions : mood === 'stressed' ? stressedQuestions : lonelyQuestions
    return questions[habit.id] || `How was your ${habit.name.toLowerCase()} today?`
  }

  const getClosingMessage = (mood: string) => {
    if (mood === 'happy') {
      return `You're doing amazing, ${userName}! Keep up these great habits. Remember, consistency is key to wellbeing.`
    } else if (mood === 'stressed') {
      return `Thank you for sharing with me, ${userName}. Remember, it's okay to take things one step at a time. Would you like to talk to a counselor? They're here to help.`
    } else {
      return `I'm glad you're here, ${userName}. You're not alone. If you'd like to talk to someone, our counselors are available and would love to connect with you.`
    }
  }

  const handleSend = () => {
    if (!input.trim()) return

    setMessages(prev => [...prev, {
      id: crypto.randomUUID(),
      role: 'user',
      content: input,
      timestamp: new Date().toISOString()
    }])
    setInput('')

    // Respond to user and ask next habit question
    setTimeout(() => {
      addAssistantMessage(config.followUp)
      setCurrentHabitIndex(prev => prev + 1)
      setTimeout(() => askAboutHabit(), 2000)
    }, 500)
  }

  return (
    <Card className="flex flex-col h-[500px] overflow-hidden">
      <div className="p-4 border-b border-border bg-muted/30">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full bg-${config.color} animate-pulse`} />
          <span className="font-medium text-foreground">MindfulMe</span>
          <span className="text-xs text-muted-foreground">is here to chat</span>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        <AnimatePresence>
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                message.role === 'user' 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-muted text-foreground'
              }`}>
                {message.content}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        
        {isTyping && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex justify-start"
          >
            <div className="bg-muted rounded-2xl px-4 py-2 text-muted-foreground">
              <span className="flex gap-1">
                <span className="animate-bounce">.</span>
                <span className="animate-bounce" style={{ animationDelay: '0.1s' }}>.</span>
                <span className="animate-bounce" style={{ animationDelay: '0.2s' }}>.</span>
              </span>
            </div>
          </motion.div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t border-border">
        <div className="flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Share your thoughts..."
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            className="flex-1"
          />
          <Button onClick={handleSend} size="icon">
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </Card>
  )
}
