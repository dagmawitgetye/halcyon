"use client"

import { motion } from 'framer-motion'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { CheckCircle, Mail, Clock, Shield, ArrowRight, Sparkles } from 'lucide-react'
import Link from 'next/link'

export default function CounselorRegisterSuccessPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-secondary/10 via-background to-primary/10 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-lg"
      >
        <Card className="p-8 text-center">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", delay: 0.2 }}
            className="w-20 h-20 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-6"
          >
            <CheckCircle className="w-10 h-10 text-secondary" />
          </motion.div>

          <h1 className="text-2xl font-bold text-foreground mb-2">
            Application Submitted!
          </h1>
          <p className="text-muted-foreground mb-8">
            Thank you for applying to be a volunteer counselor. Your application is now under review.
          </p>

          <div className="space-y-4 mb-8">
            <div className="flex items-center gap-4 p-4 bg-muted/30 rounded-lg text-left">
              <Mail className="w-8 h-8 text-primary flex-shrink-0" />
              <div>
                <p className="font-medium text-foreground">Check your email</p>
                <p className="text-sm text-muted-foreground">
                  We&apos;ve sent a confirmation to your email address.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 bg-muted/30 rounded-lg text-left">
              <Shield className="w-8 h-8 text-primary flex-shrink-0" />
              <div>
                <p className="font-medium text-foreground">Verification in progress</p>
                <p className="text-sm text-muted-foreground">
                  Our team will verify your credentials and documents.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 bg-muted/30 rounded-lg text-left">
              <Clock className="w-8 h-8 text-primary flex-shrink-0" />
              <div>
                <p className="font-medium text-foreground">Response within 3-5 days</p>
                <p className="text-sm text-muted-foreground">
                  You&apos;ll hear back from us with next steps.
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <Button asChild className="gap-2">
              <Link href="/">
                <Sparkles className="w-4 h-4" /> Back to Home
              </Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/counselors">
                View Other Counselors <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </div>
        </Card>
      </motion.div>
    </div>
  )
}
