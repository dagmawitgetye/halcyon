"use client"

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Checkbox } from '@/components/ui/checkbox'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  ArrowRight, ArrowLeft, Sparkles, Check, Upload, Shield, Heart, 
  GraduationCap, Briefcase, FileText, Clock, Star
} from 'lucide-react'
import Link from 'next/link'

const SPECIALIZATIONS = [
  "Anxiety", "Depression", "Stress Management", "Loneliness", 
  "Work-Life Balance", "Relationships", "Grief", "Self-Esteem",
  "Life Transitions", "Burnout", "Mindfulness", "Digital Wellness"
]

const DAYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']

export default function CounselorRegisterPage() {
  const router = useRouter()
  const [step, setStep] = useState(0)
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    educationLevel: '',
    fieldOfStudy: '',
    workplace: '',
    experienceYears: '',
    whyCounsel: '',
    specializations: [] as string[],
    certifications: '',
    certificateFile: null as File | null,
    availability: {} as Record<string, { start: string; end: string }>,
    agreedToTerms: false,
  })

  const steps = [
    { title: "Welcome", subtitle: "Join our mission", icon: Heart },
    { title: "Personal Info", subtitle: "Tell us about yourself", icon: GraduationCap },
    { title: "Experience", subtitle: "Your background", icon: Briefcase },
    { title: "Credentials", subtitle: "Verification documents", icon: FileText },
    { title: "Availability", subtitle: "When can you help?", icon: Clock },
    { title: "Review", subtitle: "Almost there!", icon: Star },
  ]

  const updateFormData = (field: string, value: unknown) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const toggleSpecialization = (spec: string) => {
    setFormData(prev => ({
      ...prev,
      specializations: prev.specializations.includes(spec)
        ? prev.specializations.filter(s => s !== spec)
        : [...prev.specializations, spec]
    }))
  }

  const toggleDay = (day: string) => {
    setFormData(prev => ({
      ...prev,
      availability: prev.availability[day]
        ? Object.fromEntries(Object.entries(prev.availability).filter(([d]) => d !== day))
        : { ...prev.availability, [day]: { start: '09:00', end: '17:00' } }
    }))
  }

  const canProceed = () => {
    switch (step) {
      case 1: return formData.fullName && formData.email
      case 2: return formData.educationLevel && formData.fieldOfStudy && formData.experienceYears
      case 3: return formData.whyCounsel && formData.specializations.length > 0
      case 4: return Object.keys(formData.availability).length > 0
      case 5: return formData.agreedToTerms
      default: return true
    }
  }

  const handleSubmit = () => {
    // In real app, this would submit to backend
    router.push('/counselor/register/success')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-secondary/10 via-background to-primary/10">
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-primary" />
              <span className="font-bold text-foreground">MindfulMe</span>
            </Link>
            <span className="text-sm text-muted-foreground">Counselor Registration</span>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          {/* Progress */}
          <div className="flex gap-2 mb-8">
            {steps.map((s, i) => (
              <div key={i} className="flex-1">
                <div 
                  className={`h-1 rounded-full transition-all duration-500 ${
                    i <= step ? 'bg-primary' : 'bg-muted'
                  }`}
                />
                <p className={`text-xs mt-2 ${i === step ? 'text-foreground font-medium' : 'text-muted-foreground'}`}>
                  {s.title}
                </p>
              </div>
            ))}
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              {/* Step 0: Welcome */}
              {step === 0 && (
                <Card className="p-8">
                  <div className="text-center mb-8">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="w-20 h-20 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-6"
                    >
                      <Heart className="w-10 h-10 text-secondary" />
                    </motion.div>
                    <h1 className="text-3xl font-bold text-foreground mb-4">
                      Become a Volunteer Counselor
                    </h1>
                    <p className="text-muted-foreground mb-6">
                      Join our community of verified counselors and make a real difference 
                      in people&apos;s lives. Your expertise and compassion can help those who need it most.
                    </p>
                  </div>

                  <div className="grid sm:grid-cols-3 gap-4 mb-8">
                    <div className="p-4 bg-muted/50 rounded-lg text-center">
                      <Shield className="w-8 h-8 text-primary mx-auto mb-2" />
                      <p className="text-sm font-medium text-foreground">Verified Platform</p>
                      <p className="text-xs text-muted-foreground">All counselors are verified</p>
                    </div>
                    <div className="p-4 bg-muted/50 rounded-lg text-center">
                      <Clock className="w-8 h-8 text-primary mx-auto mb-2" />
                      <p className="text-sm font-medium text-foreground">Flexible Schedule</p>
                      <p className="text-xs text-muted-foreground">Choose your availability</p>
                    </div>
                    <div className="p-4 bg-muted/50 rounded-lg text-center">
                      <Star className="w-8 h-8 text-primary mx-auto mb-2" />
                      <p className="text-sm font-medium text-foreground">Make an Impact</p>
                      <p className="text-xs text-muted-foreground">Help those in need</p>
                    </div>
                  </div>

                  <div className="bg-muted/30 p-4 rounded-lg">
                    <h3 className="font-medium text-foreground mb-2">Requirements:</h3>
                    <ul className="text-sm text-muted-foreground space-y-1">
                      <li>- Relevant education in psychology, counseling, or related field</li>
                      <li>- Professional experience in mental health support</li>
                      <li>- Valid certifications or licenses (will be verified)</li>
                      <li>- Commitment to helping others</li>
                    </ul>
                  </div>
                </Card>
              )}

              {/* Step 1: Personal Info */}
              {step === 1 && (
                <Card className="p-8">
                  <h2 className="text-2xl font-bold text-foreground mb-2">Personal Information</h2>
                  <p className="text-muted-foreground mb-6">Let&apos;s start with the basics</p>

                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="fullName">Full Name *</Label>
                      <Input
                        id="fullName"
                        value={formData.fullName}
                        onChange={(e) => updateFormData('fullName', e.target.value)}
                        placeholder="Dr. Jane Smith"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => updateFormData('email', e.target.value)}
                        placeholder="jane.smith@example.com"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone">Phone Number (optional)</Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => updateFormData('phone', e.target.value)}
                        placeholder="+1 (555) 123-4567"
                        className="mt-1"
                      />
                    </div>
                  </div>
                </Card>
              )}

              {/* Step 2: Experience */}
              {step === 2 && (
                <Card className="p-8">
                  <h2 className="text-2xl font-bold text-foreground mb-2">Education & Experience</h2>
                  <p className="text-muted-foreground mb-6">Tell us about your background</p>

                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="education">Highest Education Level *</Label>
                      <Select
                        value={formData.educationLevel}
                        onValueChange={(v) => updateFormData('educationLevel', v)}
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Select education level" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="bachelors">Bachelor&apos;s Degree</SelectItem>
                          <SelectItem value="masters">Master&apos;s Degree</SelectItem>
                          <SelectItem value="phd">PhD / Doctorate</SelectItem>
                          <SelectItem value="other">Other Certification</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="field">Field of Study *</Label>
                      <Input
                        id="field"
                        value={formData.fieldOfStudy}
                        onChange={(e) => updateFormData('fieldOfStudy', e.target.value)}
                        placeholder="e.g., Clinical Psychology, Counseling, Social Work"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="workplace">Current Workplace</Label>
                      <Input
                        id="workplace"
                        value={formData.workplace}
                        onChange={(e) => updateFormData('workplace', e.target.value)}
                        placeholder="e.g., Community Health Center, Private Practice"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="experience">Years of Experience *</Label>
                      <Select
                        value={formData.experienceYears}
                        onValueChange={(v) => updateFormData('experienceYears', v)}
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Select years of experience" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1-2">1-2 years</SelectItem>
                          <SelectItem value="3-5">3-5 years</SelectItem>
                          <SelectItem value="6-10">6-10 years</SelectItem>
                          <SelectItem value="10+">10+ years</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </Card>
              )}

              {/* Step 3: Credentials */}
              {step === 3 && (
                <Card className="p-8">
                  <h2 className="text-2xl font-bold text-foreground mb-2">Credentials & Motivation</h2>
                  <p className="text-muted-foreground mb-6">Why do you want to counsel?</p>

                  <div className="space-y-6">
                    <div>
                      <Label htmlFor="why">Why do you want to be a volunteer counselor? *</Label>
                      <Textarea
                        id="why"
                        value={formData.whyCounsel}
                        onChange={(e) => updateFormData('whyCounsel', e.target.value)}
                        placeholder="Share your motivation and what drives you to help others..."
                        className="mt-1 min-h-[120px]"
                      />
                    </div>

                    <div>
                      <Label>Specializations * (select at least one)</Label>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-2">
                        {SPECIALIZATIONS.map((spec) => (
                          <button
                            key={spec}
                            type="button"
                            onClick={() => toggleSpecialization(spec)}
                            className={`p-2 text-sm rounded-lg border transition-all ${
                              formData.specializations.includes(spec)
                                ? 'border-primary bg-primary/10 text-foreground'
                                : 'border-border text-muted-foreground hover:border-primary/50'
                            }`}
                          >
                            {spec}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="certs">Certifications & Licenses</Label>
                      <Textarea
                        id="certs"
                        value={formData.certifications}
                        onChange={(e) => updateFormData('certifications', e.target.value)}
                        placeholder="List your relevant certifications and license numbers..."
                        className="mt-1"
                      />
                    </div>

                    <div>
                      <Label>Upload Certificate (PDF, JPG, PNG)</Label>
                      <div className="mt-2 border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary/50 transition-colors cursor-pointer">
                        <Upload className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                        <p className="text-sm text-muted-foreground">
                          Click to upload or drag and drop
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Max file size: 10MB
                        </p>
                      </div>
                    </div>
                  </div>
                </Card>
              )}

              {/* Step 4: Availability */}
              {step === 4 && (
                <Card className="p-8">
                  <h2 className="text-2xl font-bold text-foreground mb-2">Availability</h2>
                  <p className="text-muted-foreground mb-6">When can you offer support?</p>

                  <div className="space-y-3">
                    {DAYS.map((day) => {
                      const isSelected = !!formData.availability[day]
                      return (
                        <div 
                          key={day}
                          className={`p-4 rounded-lg border transition-all ${
                            isSelected ? 'border-primary bg-primary/5' : 'border-border'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <label className="flex items-center gap-3 cursor-pointer">
                              <Checkbox
                                checked={isSelected}
                                onCheckedChange={() => toggleDay(day)}
                              />
                              <span className="font-medium text-foreground capitalize">{day}</span>
                            </label>
                            {isSelected && (
                              <div className="flex items-center gap-2">
                                <Input
                                  type="time"
                                  value={formData.availability[day]?.start || '09:00'}
                                  onChange={(e) => setFormData(prev => ({
                                    ...prev,
                                    availability: {
                                      ...prev.availability,
                                      [day]: { ...prev.availability[day], start: e.target.value }
                                    }
                                  }))}
                                  className="w-28"
                                />
                                <span className="text-muted-foreground">to</span>
                                <Input
                                  type="time"
                                  value={formData.availability[day]?.end || '17:00'}
                                  onChange={(e) => setFormData(prev => ({
                                    ...prev,
                                    availability: {
                                      ...prev.availability,
                                      [day]: { ...prev.availability[day], end: e.target.value }
                                    }
                                  }))}
                                  className="w-28"
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </Card>
              )}

              {/* Step 5: Review */}
              {step === 5 && (
                <Card className="p-8">
                  <h2 className="text-2xl font-bold text-foreground mb-2">Review Your Application</h2>
                  <p className="text-muted-foreground mb-6">Please review before submitting</p>

                  <div className="space-y-6">
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Full Name</p>
                        <p className="font-medium text-foreground">{formData.fullName}</p>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Email</p>
                        <p className="font-medium text-foreground">{formData.email}</p>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Education</p>
                        <p className="font-medium text-foreground capitalize">{formData.educationLevel?.replace('-', ' ')}</p>
                      </div>
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Field</p>
                        <p className="font-medium text-foreground">{formData.fieldOfStudy}</p>
                      </div>
                    </div>

                    <div className="p-4 bg-muted/30 rounded-lg">
                      <p className="text-xs text-muted-foreground mb-2">Specializations</p>
                      <div className="flex flex-wrap gap-2">
                        {formData.specializations.map((spec) => (
                          <span key={spec} className="px-2 py-1 bg-primary/10 text-primary rounded text-sm">
                            {spec}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="p-4 bg-muted/30 rounded-lg">
                      <p className="text-xs text-muted-foreground mb-2">Available Days</p>
                      <p className="font-medium text-foreground capitalize">
                        {Object.keys(formData.availability).join(', ') || 'None selected'}
                      </p>
                    </div>

                    <div className="border border-border rounded-lg p-4">
                      <label className="flex items-start gap-3 cursor-pointer">
                        <Checkbox
                          checked={formData.agreedToTerms}
                          onCheckedChange={(v) => updateFormData('agreedToTerms', v)}
                          className="mt-1"
                        />
                        <span className="text-sm text-muted-foreground">
                          I confirm that all information provided is accurate and I agree to the 
                          terms of service and code of conduct for volunteer counselors. I understand 
                          my credentials will be verified before approval.
                        </span>
                      </label>
                    </div>
                  </div>
                </Card>
              )}
            </motion.div>
          </AnimatePresence>

          {/* Navigation */}
          <div className="flex justify-between mt-6">
            <Button
              variant="ghost"
              onClick={() => setStep(s => s - 1)}
              disabled={step === 0}
              className="gap-2"
            >
              <ArrowLeft className="w-4 h-4" /> Back
            </Button>
            
            {step < 5 ? (
              <Button
                onClick={() => setStep(s => s + 1)}
                disabled={!canProceed()}
                className="gap-2"
              >
                Continue <ArrowRight className="w-4 h-4" />
              </Button>
            ) : (
              <Button 
                onClick={handleSubmit} 
                disabled={!canProceed()}
                className="gap-2"
              >
                Submit Application <Check className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
