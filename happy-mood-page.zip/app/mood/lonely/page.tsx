"use client"

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { Sparkles, Cloud, Heart, Users, MessageCircle, Phone, HandHeart, Smile } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { useApp } from '@/lib/context'
import { HabitChat } from '@/components/mood/habit-chat'
import { StreakCard } from '@/components/mood/streak-card'
import { CounselorList } from '@/components/mood/counselor-list'
import { DEFAULT_HABITS } from '@/lib/types'
import Link from 'next/link'

export default function LonelyMoodPage() {
  const router = useRouter()
  const { user, isOnboarded, updateStreak } = useApp()

  useEffect(() => {
    if (!isOnboarded) {
      router.push('/onboarding')
    } else {
      updateStreak()
    }
  }, [isOnboarded, router, updateStreak])

  if (!user) return null

  const habits = user.habits.length > 0 ? user.habits : DEFAULT_HABITS.slice(0, 4)

  const connectionSuggestions = [
    { icon: MessageCircle, title: "Send a message", desc: "Reach out to someone you haven't talked to in a while" },
    { icon: Users, title: "Join a community", desc: "Find groups that share your interests" },
    { icon: HandHeart, title: "Help someone", desc: "Volunteering can create meaningful connections" },
  ]

  const communityStories = [
    { 
      name: "Alex", 
      story: "I felt isolated for months after moving to a new city. Talking to a counselor here helped me find ways to build new friendships. Now I have a small but wonderful group of friends.",
      time: "2 months ago"
    },
    { 
      name: "Jordan", 
      story: "Some days are harder than others, but checking in here reminds me I'm not alone. The community gets it.",
      time: "1 week ago"
    },
    { 
      name: "Sam", 
      story: "Started volunteering based on a suggestion from my counselor. It completely changed my perspective and I met amazing people.",
      time: "3 weeks ago"
    },
  ]

  return (
    <main className="min-h-screen bg-gradient-to-br from-secondary/10 via-background to-primary/5">
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-sm sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-primary" />
              <span className="font-bold text-foreground">MindfulMe</span>
            </Link>
            <nav className="flex items-center gap-4">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/counselors">Find Counselors</Link>
              </Button>
              <Button size="sm" className="gap-2 bg-secondary text-secondary-foreground hover:bg-secondary/90">
                <Heart className="w-4 h-4" /> Connect Now
              </Button>
            </nav>
          </div>
        </div>
      </header>

      {/* Gentle Banner */}
      <div className="bg-secondary/10 border-b border-secondary/20 py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center gap-3 text-center">
            <Heart className="w-5 h-5 text-secondary" />
            <span className="text-foreground">
              You&apos;re not alone. We&apos;re here with you, and so are many others who understand.
            </span>
          </div>
        </div>
      </div>

      {/* Hero */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-2xl mx-auto mb-12"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", delay: 0.2 }}
              className="w-20 h-20 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-6"
            >
              <Cloud className="w-10 h-10 text-secondary" />
            </motion.div>
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Hey {user.name}, We&apos;re Here For You
            </h1>
            <p className="text-lg text-muted-foreground">
              We noticed you might be feeling a bit disconnected lately. 
              That&apos;s okay - these feelings are valid, and they can change.
            </p>
          </motion.div>

          {/* Connection Suggestions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mb-12"
          >
            <h2 className="text-xl font-semibold text-foreground mb-4 text-center">
              Small Steps to Connection
            </h2>
            <div className="grid md:grid-cols-3 gap-4 max-w-4xl mx-auto">
              {connectionSuggestions.map((suggestion, i) => (
                <motion.div
                  key={suggestion.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + i * 0.1 }}
                >
                  <Card className="p-6 h-full bg-card hover:bg-secondary/5 transition-colors cursor-pointer group">
                    <suggestion.icon className="w-8 h-8 text-secondary mb-4 group-hover:scale-110 transition-transform" />
                    <h3 className="font-semibold text-foreground mb-2">{suggestion.title}</h3>
                    <p className="text-sm text-muted-foreground">{suggestion.desc}</p>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-8 mb-12">
            {/* Chat Section */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                <MessageCircle className="w-5 h-5 text-secondary" />
                Let&apos;s check in
              </h2>
              <HabitChat habits={habits} userName={user.name} mood="lonely" />
            </motion.div>

            {/* Streak & Community Stories */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
              className="space-y-6"
            >
              <StreakCard 
                streakDays={user.streak_days} 
                totalCheckins={user.total_checkins}
              />
              
              {/* Community Stories */}
              <Card className="p-6">
                <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                  <Users className="w-5 h-5 text-secondary" />
                  You&apos;re Not Alone
                </h3>
                <div className="space-y-4">
                  {communityStories.map((story, i) => (
                    <div key={i} className="p-4 bg-muted/50 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-8 h-8 rounded-full bg-secondary/20 flex items-center justify-center">
                          <Smile className="w-4 h-4 text-secondary" />
                        </div>
                        <span className="font-medium text-foreground">{story.name}</span>
                        <span className="text-xs text-muted-foreground">- {story.time}</span>
                      </div>
                      <p className="text-sm text-muted-foreground italic">&quot;{story.story}&quot;</p>
                    </div>
                  ))}
                </div>
              </Card>
            </motion.div>
          </div>

          {/* Counselor Section - Emphasized for lonely mood */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card className="p-8 mb-8 bg-gradient-to-r from-secondary/10 to-primary/5 border-secondary/20 text-center">
              <Heart className="w-12 h-12 text-secondary mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-foreground mb-2">
                Someone Wants to Listen
              </h2>
              <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
                Our volunteer counselors are here because they genuinely want to help. 
                Sometimes, just having someone to talk to can make all the difference.
              </p>
              <Button size="lg" className="gap-2 bg-secondary text-secondary-foreground hover:bg-secondary/90">
                <Phone className="w-4 h-4" /> Talk to Someone Now
              </Button>
            </Card>
            <CounselorList mood="lonely" />
          </motion.div>

          {/* Mood Navigation */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
            className="mt-12 text-center"
          >
            <p className="text-sm text-muted-foreground mb-4">How are you feeling?</p>
            <div className="flex justify-center gap-4">
              <Button variant="outline" asChild>
                <Link href="/mood/happy">I&apos;m feeling better</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/mood/stressed">I&apos;m feeling stressed</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 mt-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground mb-2">
            Remember: reaching out is a sign of strength, not weakness.
          </p>
          <p className="text-xs text-muted-foreground">
            MindfulMe - Your personal wellness companion
          </p>
        </div>
      </footer>
    </main>
  )
}
