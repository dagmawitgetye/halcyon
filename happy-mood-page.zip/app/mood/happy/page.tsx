"use client"

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { Sparkles, Sun, TrendingUp, Heart, Users, ArrowRight } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { useApp } from '@/lib/context'
import { HabitChat } from '@/components/mood/habit-chat'
import { StreakCard } from '@/components/mood/streak-card'
import { CounselorList } from '@/components/mood/counselor-list'
import { DEFAULT_HABITS } from '@/lib/types'
import Link from 'next/link'

export default function HappyMoodPage() {
  const router = useRouter()
  const { user, isOnboarded, updateStreak } = useApp()

  useEffect(() => {
    if (!isOnboarded) {
      router.push('/onboarding')
    } else {
      updateStreak()
    }
  }, [isOnboarded, router, updateStreak])

  if (!user) return null

  const habits = user.habits.length > 0 ? user.habits : DEFAULT_HABITS.slice(0, 4)

  return (
    <main className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-secondary/10">
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-sm sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-primary" />
              <span className="font-bold text-foreground">MindfulMe</span>
            </Link>
            <nav className="flex items-center gap-4">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/counselors">Find Counselors</Link>
              </Button>
              <Button variant="outline" size="sm" asChild>
                <Link href="/counselor/register">Become a Counselor</Link>
              </Button>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-2xl mx-auto mb-12"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", delay: 0.2 }}
              className="w-20 h-20 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6"
            >
              <Sun className="w-10 h-10 text-primary" />
            </motion.div>
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              You&apos;re Doing Amazing, {user.name}!
            </h1>
            <p className="text-lg text-muted-foreground">
              Your positive habits are paying off. Let&apos;s celebrate your wins and keep the momentum going!
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-8 mb-12">
            {/* Chat Section */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
            >
              <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                <Heart className="w-5 h-5 text-primary" />
                How was your day?
              </h2>
              <HabitChat habits={habits} userName={user.name} mood="happy" />
            </motion.div>

            {/* Streak & Stats */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              className="space-y-6"
            >
              <StreakCard 
                streakDays={user.streak_days} 
                totalCheckins={user.total_checkins}
              />
              
              {/* Quick Stats */}
              <Card className="p-6">
                <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-secondary" />
                  Your Positive Patterns
                </h3>
                <div className="space-y-3">
                  {habits.slice(0, 4).map((habit, i) => (
                    <div key={habit.id} className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                      <span className="text-2xl">{habit.icon}</span>
                      <div className="flex-1">
                        <p className="font-medium text-foreground">{habit.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {habit.normalFrequency === 'daily' ? 'Daily habit' : 'Regular activity'}
                        </p>
                      </div>
                      <div className="text-xs text-secondary font-medium">On track</div>
                    </div>
                  ))}
                </div>
              </Card>
            </motion.div>
          </div>

          {/* Growth Suggestions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mb-12"
          >
            <Card className="p-6 bg-gradient-to-r from-secondary/10 to-primary/10 border-0">
              <h3 className="font-semibold text-foreground mb-4">Keep Growing</h3>
              <div className="grid sm:grid-cols-3 gap-4">
                {[
                  { title: "Try a new habit", desc: "Add meditation or journaling to your routine" },
                  { title: "Share your success", desc: "Inspire others in the community" },
                  { title: "Set a new goal", desc: "Challenge yourself this week" },
                ].map((item, i) => (
                  <div key={i} className="p-4 bg-card rounded-lg">
                    <h4 className="font-medium text-foreground mb-1">{item.title}</h4>
                    <p className="text-sm text-muted-foreground">{item.desc}</p>
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>

          {/* Counselor Section */}
          <CounselorList mood="happy" />

          {/* Mood Navigation */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="mt-12 text-center"
          >
            <p className="text-sm text-muted-foreground mb-4">Feeling different today?</p>
            <div className="flex justify-center gap-4">
              <Button variant="outline" asChild>
                <Link href="/mood/stressed">I&apos;m feeling stressed</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/mood/lonely">I&apos;m feeling lonely</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 mt-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground">
            MindfulMe - Your personal wellness companion
          </p>
        </div>
      </footer>
    </main>
  )
}
