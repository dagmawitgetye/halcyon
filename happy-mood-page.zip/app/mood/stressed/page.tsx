"use client"

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { motion } from 'framer-motion'
import { Sparkles, CloudRain, AlertCircle, Brain, Leaf, Phone, HeartHandshake } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { useApp } from '@/lib/context'
import { HabitChat } from '@/components/mood/habit-chat'
import { StreakCard } from '@/components/mood/streak-card'
import { CounselorList } from '@/components/mood/counselor-list'
import { DEFAULT_HABITS } from '@/lib/types'
import Link from 'next/link'

export default function StressedMoodPage() {
  const router = useRouter()
  const { user, isOnboarded, updateStreak } = useApp()

  useEffect(() => {
    if (!isOnboarded) {
      router.push('/onboarding')
    } else {
      updateStreak()
    }
  }, [isOnboarded, router, updateStreak])

  if (!user) return null

  const habits = user.habits.length > 0 ? user.habits : DEFAULT_HABITS.slice(0, 4)

  const copingStrategies = [
    { icon: Brain, title: "5-4-3-2-1 Grounding", desc: "Name 5 things you see, 4 you hear, 3 you feel, 2 you smell, 1 you taste" },
    { icon: Leaf, title: "Box Breathing", desc: "Breathe in 4 seconds, hold 4, out 4, hold 4. Repeat 4 times." },
    { icon: HeartHandshake, title: "Talk to Someone", desc: "Reach out to a friend, family member, or counselor" },
  ]

  return (
    <main className="min-h-screen bg-gradient-to-br from-accent/10 via-background to-muted/20">
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-sm sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-primary" />
              <span className="font-bold text-foreground">MindfulMe</span>
            </Link>
            <nav className="flex items-center gap-4">
              <Button variant="ghost" size="sm" asChild>
                <Link href="/counselors">Find Counselors</Link>
              </Button>
              <Button size="sm" className="gap-2">
                <Phone className="w-4 h-4" /> Get Help Now
              </Button>
            </nav>
          </div>
        </div>
      </header>

      {/* Alert Banner */}
      <div className="bg-accent/20 border-b border-accent/30 py-3">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center gap-2 text-sm">
            <AlertCircle className="w-4 h-4 text-accent-foreground" />
            <span className="text-foreground">
              We noticed some changes in your patterns. Remember, it&apos;s okay to ask for help.
            </span>
            <Button variant="link" size="sm" className="text-accent-foreground font-medium" asChild>
              <Link href="/counselors">Talk to a counselor</Link>
            </Button>
          </div>
        </div>
      </div>

      {/* Hero */}
      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-2xl mx-auto mb-12"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", delay: 0.2 }}
              className="w-20 h-20 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-6"
            >
              <CloudRain className="w-10 h-10 text-accent-foreground" />
            </motion.div>
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Take a Breath, {user.name}
            </h1>
            <p className="text-lg text-muted-foreground">
              We noticed your screen time is higher than usual and some habits have changed. 
              That&apos;s okay - let&apos;s work through this together.
            </p>
          </motion.div>

          {/* Coping Strategies */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mb-12"
          >
            <h2 className="text-xl font-semibold text-foreground mb-4 text-center">
              Quick Relief Techniques
            </h2>
            <div className="grid md:grid-cols-3 gap-4 max-w-4xl mx-auto">
              {copingStrategies.map((strategy, i) => (
                <motion.div
                  key={strategy.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + i * 0.1 }}
                >
                  <Card className="p-6 h-full bg-card hover:bg-muted/50 transition-colors cursor-pointer">
                    <strategy.icon className="w-8 h-8 text-accent mb-4" />
                    <h3 className="font-semibold text-foreground mb-2">{strategy.title}</h3>
                    <p className="text-sm text-muted-foreground">{strategy.desc}</p>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-8 mb-12">
            {/* Chat Section */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
            >
              <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                <HeartHandshake className="w-5 h-5 text-accent" />
                Let&apos;s talk about it
              </h2>
              <HabitChat habits={habits} userName={user.name} mood="stressed" />
            </motion.div>

            {/* Streak & Pattern Changes */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 }}
              className="space-y-6"
            >
              <StreakCard 
                streakDays={user.streak_days} 
                totalCheckins={user.total_checkins}
              />
              
              {/* Pattern Changes Alert */}
              <Card className="p-6 border-accent/30 bg-accent/5">
                <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-accent" />
                  Changes We&apos;ve Noticed
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-background rounded-lg">
                    <span className="text-sm text-foreground">Screen time</span>
                    <span className="text-sm text-accent font-medium">+45% today</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-background rounded-lg">
                    <span className="text-sm text-foreground">Exercise</span>
                    <span className="text-sm text-muted-foreground">Skipped today</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-background rounded-lg">
                    <span className="text-sm text-foreground">Sleep quality</span>
                    <span className="text-sm text-accent font-medium">Below average</span>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-4">
                  These changes can be temporary. The important thing is recognizing them.
                </p>
              </Card>
            </motion.div>
          </div>

          {/* Counselor Section - More Prominent */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <Card className="p-6 mb-8 bg-gradient-to-r from-accent/10 to-secondary/10 border-accent/20">
              <div className="text-center mb-6">
                <h2 className="text-2xl font-bold text-foreground mb-2">
                  You Don&apos;t Have to Handle This Alone
                </h2>
                <p className="text-muted-foreground">
                  Our verified counselors are trained to help with stress and anxiety. 
                  A conversation can make a big difference.
                </p>
              </div>
            </Card>
            <CounselorList mood="stressed" />
          </motion.div>

          {/* Mood Navigation */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
            className="mt-12 text-center"
          >
            <p className="text-sm text-muted-foreground mb-4">How are you feeling now?</p>
            <div className="flex justify-center gap-4">
              <Button variant="outline" asChild>
                <Link href="/mood/happy">I&apos;m feeling better</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/mood/lonely">I&apos;m feeling lonely</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 mt-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground mb-2">
            If you&apos;re in crisis, please contact emergency services or a crisis helpline.
          </p>
          <p className="text-xs text-muted-foreground">
            MindfulMe - Your personal wellness companion
          </p>
        </div>
      </footer>
    </main>
  )
}
