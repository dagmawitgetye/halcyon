"use client"

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { 
  Search, Filter, Star, Shield, Calendar, Clock, MessageCircle, 
  X, ChevronLeft, ChevronRight, Check, Sparkles, Heart
} from 'lucide-react'
import { Counselor } from '@/lib/types'
import Link from 'next/link'
import { format, addDays, startOfWeek } from 'date-fns'

const SAMPLE_COUNSELORS: Counselor[] = [
  {
    id: '1',
    user_id: 'u1',
    full_name: 'Dr. Sarah Chen',
    email: 'sarah@example.com',
    education_level: 'PhD',
    field_of_study: 'Clinical Psychology',
    workplace: 'Wellness Center',
    experience_years: 8,
    why_counsel: 'I believe everyone deserves support',
    certifications: ['Licensed Clinical Psychologist', 'CBT Certified'],
    certificate_urls: [],
    specializations: ['Anxiety', 'Stress Management', 'Work-Life Balance'],
    availability: [
      { day: 'monday', start_time: '09:00', end_time: '17:00' },
      { day: 'wednesday', start_time: '09:00', end_time: '17:00' },
      { day: 'friday', start_time: '09:00', end_time: '15:00' },
    ],
    is_verified: true,
    is_active: true,
    rating: 4.9,
    total_sessions: 234,
    created_at: new Date().toISOString()
  },
  {
    id: '2',
    user_id: 'u2',
    full_name: 'Michael Roberts',
    email: 'michael@example.com',
    education_level: 'Masters',
    field_of_study: 'Counseling Psychology',
    workplace: 'Community Health Center',
    experience_years: 5,
    why_counsel: 'Mental health is a journey we take together',
    certifications: ['Licensed Counselor', 'Trauma-Informed Care'],
    certificate_urls: [],
    specializations: ['Depression', 'Loneliness', 'Life Transitions'],
    availability: [
      { day: 'tuesday', start_time: '10:00', end_time: '18:00' },
      { day: 'thursday', start_time: '10:00', end_time: '18:00' },
    ],
    is_verified: true,
    is_active: true,
    rating: 4.8,
    total_sessions: 189,
    created_at: new Date().toISOString()
  },
  {
    id: '3',
    user_id: 'u3',
    full_name: 'Dr. Emily Watson',
    email: 'emily@example.com',
    education_level: 'PhD',
    field_of_study: 'Behavioral Health',
    workplace: 'Private Practice',
    experience_years: 12,
    why_counsel: 'Helping others find their path to wellness',
    certifications: ['Licensed Psychologist', 'Mindfulness Instructor'],
    certificate_urls: [],
    specializations: ['Mindfulness', 'Digital Wellness', 'Burnout'],
    availability: [
      { day: 'monday', start_time: '08:00', end_time: '16:00' },
      { day: 'tuesday', start_time: '08:00', end_time: '16:00' },
      { day: 'wednesday', start_time: '08:00', end_time: '16:00' },
    ],
    is_verified: true,
    is_active: true,
    rating: 4.95,
    total_sessions: 412,
    created_at: new Date().toISOString()
  },
  {
    id: '4',
    user_id: 'u4',
    full_name: 'Dr. James Lee',
    email: 'james@example.com',
    education_level: 'PhD',
    field_of_study: 'Social Psychology',
    workplace: 'University Counseling Center',
    experience_years: 10,
    why_counsel: 'Supporting students and young adults',
    certifications: ['Licensed Psychologist', 'Youth Counselor'],
    certificate_urls: [],
    specializations: ['Self-Esteem', 'Relationships', 'Academic Stress'],
    availability: [
      { day: 'thursday', start_time: '09:00', end_time: '17:00' },
      { day: 'friday', start_time: '09:00', end_time: '17:00' },
    ],
    is_verified: true,
    is_active: true,
    rating: 4.85,
    total_sessions: 298,
    created_at: new Date().toISOString()
  },
]

const TIME_SLOTS = ['09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00']

export default function CounselorsPage() {
  const [search, setSearch] = useState('')
  const [selectedCounselor, setSelectedCounselor] = useState<Counselor | null>(null)
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)
  const [selectedTime, setSelectedTime] = useState<string | null>(null)
  const [weekStart, setWeekStart] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }))
  const [isScheduled, setIsScheduled] = useState(false)
  const [filterSpec, setFilterSpec] = useState<string | null>(null)

  const allSpecs = [...new Set(SAMPLE_COUNSELORS.flatMap(c => c.specializations))]

  const filteredCounselors = SAMPLE_COUNSELORS.filter(c => {
    const matchesSearch = c.full_name.toLowerCase().includes(search.toLowerCase()) ||
      c.specializations.some(s => s.toLowerCase().includes(search.toLowerCase()))
    const matchesFilter = !filterSpec || c.specializations.includes(filterSpec)
    return matchesSearch && matchesFilter
  })

  const getWeekDays = () => {
    return Array.from({ length: 7 }, (_, i) => addDays(weekStart, i))
  }

  const isDateAvailable = (date: Date, counselor: Counselor) => {
    const dayName = format(date, 'EEEE').toLowerCase()
    return counselor.availability.some(a => a.day === dayName)
  }

  const handleSchedule = () => {
    setIsScheduled(true)
    setTimeout(() => {
      setSelectedCounselor(null)
      setSelectedDate(null)
      setSelectedTime(null)
      setIsScheduled(false)
    }, 3000)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/80 backdrop-blur-sm sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-primary" />
              <span className="font-bold text-foreground">MindfulMe</span>
            </Link>
            <Button variant="outline" size="sm" asChild>
              <Link href="/counselor/register">Become a Counselor</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Hero */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Find Your Counselor</h1>
          <p className="text-muted-foreground">
            Connect with verified volunteer counselors who are here to support you
          </p>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by name or specialization..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button 
              variant={filterSpec ? "outline" : "secondary"} 
              size="sm"
              onClick={() => setFilterSpec(null)}
            >
              All
            </Button>
            {allSpecs.slice(0, 4).map(spec => (
              <Button
                key={spec}
                variant={filterSpec === spec ? "default" : "outline"}
                size="sm"
                onClick={() => setFilterSpec(filterSpec === spec ? null : spec)}
              >
                {spec}
              </Button>
            ))}
          </div>
        </div>

        {/* Counselors Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCounselors.map((counselor, i) => (
            <motion.div
              key={counselor.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <Card className="p-6 h-full flex flex-col hover:shadow-lg transition-shadow">
                <div className="flex items-start gap-4 mb-4">
                  <Avatar className="w-14 h-14">
                    <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${counselor.id}`} />
                    <AvatarFallback>{counselor.full_name.slice(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-foreground">{counselor.full_name}</h3>
                      {counselor.is_verified && (
                        <Shield className="w-4 h-4 text-primary" />
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">{counselor.field_of_study}</p>
                    <p className="text-xs text-muted-foreground">{counselor.workplace}</p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-1 mb-4">
                  {counselor.specializations.map((spec, i) => (
                    <Badge key={i} variant="secondary" className="text-xs">
                      {spec}
                    </Badge>
                  ))}
                </div>

                <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                  <span className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-primary fill-primary" />
                    {counselor.rating.toFixed(1)}
                  </span>
                  <span className="flex items-center gap-1">
                    <MessageCircle className="w-4 h-4" />
                    {counselor.total_sessions}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {counselor.experience_years}y
                  </span>
                </div>

                <div className="mt-auto">
                  <Button 
                    className="w-full gap-2"
                    onClick={() => setSelectedCounselor(counselor)}
                  >
                    <Calendar className="w-4 h-4" /> Schedule Session
                  </Button>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </main>

      {/* Scheduling Modal */}
      <AnimatePresence>
        {selectedCounselor && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-foreground/50 flex items-center justify-center z-50 p-4"
            onClick={() => !isScheduled && setSelectedCounselor(null)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-2xl"
            >
              <Card className="p-6 max-h-[90vh] overflow-y-auto">
                {isScheduled ? (
                  <div className="text-center py-8">
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="w-16 h-16 bg-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4"
                    >
                      <Check className="w-8 h-8 text-secondary" />
                    </motion.div>
                    <h3 className="text-xl font-bold text-foreground mb-2">Session Scheduled!</h3>
                    <p className="text-muted-foreground mb-4">
                      Your session with {selectedCounselor.full_name} is confirmed for<br />
                      <strong>{selectedDate && format(selectedDate, 'EEEE, MMMM d')}</strong> at <strong>{selectedTime}</strong>
                    </p>
                    <p className="text-sm text-muted-foreground">
                      You&apos;ll receive a confirmation email with meeting details.
                    </p>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${selectedCounselor.id}`} />
                          <AvatarFallback>{selectedCounselor.full_name.slice(0, 2).toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-semibold text-foreground">{selectedCounselor.full_name}</h3>
                          <p className="text-sm text-muted-foreground">{selectedCounselor.field_of_study}</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" onClick={() => setSelectedCounselor(null)}>
                        <X className="w-4 h-4" />
                      </Button>
                    </div>

                    <h4 className="font-medium text-foreground mb-4">Select a Date</h4>
                    
                    {/* Week Navigation */}
                    <div className="flex items-center justify-between mb-4">
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => setWeekStart(addDays(weekStart, -7))}
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </Button>
                      <span className="text-sm font-medium text-foreground">
                        {format(weekStart, 'MMM d')} - {format(addDays(weekStart, 6), 'MMM d, yyyy')}
                      </span>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => setWeekStart(addDays(weekStart, 7))}
                      >
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    </div>

                    {/* Date Grid */}
                    <div className="grid grid-cols-7 gap-2 mb-6">
                      {getWeekDays().map((date) => {
                        const isAvailable = isDateAvailable(date, selectedCounselor)
                        const isSelected = selectedDate?.toDateString() === date.toDateString()
                        const isPast = date < new Date()
                        
                        return (
                          <button
                            key={date.toISOString()}
                            disabled={!isAvailable || isPast}
                            onClick={() => { setSelectedDate(date); setSelectedTime(null) }}
                            className={`p-3 rounded-lg text-center transition-all ${
                              isSelected
                                ? 'bg-primary text-primary-foreground'
                                : isAvailable && !isPast
                                ? 'bg-muted hover:bg-muted/80 text-foreground'
                                : 'bg-muted/30 text-muted-foreground cursor-not-allowed'
                            }`}
                          >
                            <div className="text-xs">{format(date, 'EEE')}</div>
                            <div className="text-lg font-medium">{format(date, 'd')}</div>
                          </button>
                        )
                      })}
                    </div>

                    {/* Time Slots */}
                    {selectedDate && (
                      <>
                        <h4 className="font-medium text-foreground mb-4">Select a Time</h4>
                        <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 mb-6">
                          {TIME_SLOTS.map((time) => {
                            const isSelected = selectedTime === time
                            return (
                              <button
                                key={time}
                                onClick={() => setSelectedTime(time)}
                                className={`p-3 rounded-lg text-center transition-all ${
                                  isSelected
                                    ? 'bg-primary text-primary-foreground'
                                    : 'bg-muted hover:bg-muted/80 text-foreground'
                                }`}
                              >
                                {time}
                              </button>
                            )
                          })}
                        </div>
                      </>
                    )}

                    {/* Confirm Button */}
                    <Button 
                      className="w-full gap-2"
                      disabled={!selectedDate || !selectedTime}
                      onClick={handleSchedule}
                    >
                      <Heart className="w-4 h-4" />
                      Confirm Session {selectedDate && selectedTime && `- ${format(selectedDate, 'MMM d')} at ${selectedTime}`}
                    </Button>
                  </>
                )}
              </Card>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
