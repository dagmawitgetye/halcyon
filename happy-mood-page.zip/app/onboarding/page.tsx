"use client"

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { useApp } from '@/lib/context'
import { DEFAULT_HABITS, UserHabit } from '@/lib/types'
import { ArrowRight, ArrowLeft, Sparkles, Check } from 'lucide-react'

export default function OnboardingPage() {
  const router = useRouter()
  const { completeOnboarding } = useApp()
  const [step, setStep] = useState(0)
  const [name, setName] = useState('')
  const [selectedHabits, setSelectedHabits] = useState<UserHabit[]>([])

  const steps = [
    { title: "Welcome", subtitle: "Let's get to know you" },
    { title: "Your Name", subtitle: "What should we call you?" },
    { title: "Your Habits", subtitle: "What do you normally do?" },
    { title: "All Set", subtitle: "You're ready to start" },
  ]

  const toggleHabit = (habit: UserHabit) => {
    setSelectedHabits(prev => 
      prev.find(h => h.id === habit.id)
        ? prev.filter(h => h.id !== habit.id)
        : [...prev, habit]
    )
  }

  const handleComplete = () => {
    completeOnboarding(name, selectedHabits)
    router.push('/mood/happy')
  }

  const canProceed = () => {
    if (step === 1 && !name.trim()) return false
    if (step === 2 && selectedHabits.length < 2) return false
    return true
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/20 via-background to-secondary/20 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Progress */}
        <div className="flex gap-2 mb-8">
          {steps.map((_, i) => (
            <div 
              key={i}
              className={`h-1 flex-1 rounded-full transition-all duration-500 ${
                i <= step ? 'bg-primary' : 'bg-muted'
              }`}
            />
          ))}
        </div>

        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            {/* Step 0: Welcome */}
            {step === 0 && (
              <Card className="p-8 text-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring" }}
                  className="w-24 h-24 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6"
                >
                  <Sparkles className="w-12 h-12 text-primary" />
                </motion.div>
                <h1 className="text-3xl font-bold text-foreground mb-4">Welcome to MindfulMe</h1>
                <p className="text-muted-foreground text-lg mb-6">
                  Your personal companion for understanding yourself better. 
                  We&apos;ll learn your daily habits to help you stay balanced and connected.
                </p>
                <p className="text-sm text-muted-foreground mb-8">
                  This takes about 2 minutes
                </p>
              </Card>
            )}

            {/* Step 1: Name */}
            {step === 1 && (
              <Card className="p-8">
                <h2 className="text-2xl font-bold text-foreground mb-2">{steps[1].title}</h2>
                <p className="text-muted-foreground mb-6">{steps[1].subtitle}</p>
                <Input
                  type="text"
                  placeholder="Enter your name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="text-lg p-6"
                  autoFocus
                />
              </Card>
            )}

            {/* Step 2: Habits */}
            {step === 2 && (
              <Card className="p-8">
                <h2 className="text-2xl font-bold text-foreground mb-2">{steps[2].title}</h2>
                <p className="text-muted-foreground mb-2">{steps[2].subtitle}</p>
                <p className="text-sm text-muted-foreground mb-6">
                  Select at least 2 habits that are part of your normal routine. 
                  We&apos;ll use this to understand when something feels different.
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4">
                  {DEFAULT_HABITS.map((habit) => {
                    const isSelected = selectedHabits.find(h => h.id === habit.id)
                    return (
                      <motion.button
                        key={habit.id}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => toggleHabit(habit)}
                        className={`p-4 rounded-xl border-2 transition-all text-left ${
                          isSelected 
                            ? 'border-primary bg-primary/10' 
                            : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-2xl">{habit.icon}</span>
                          <span className="font-medium text-foreground">{habit.name}</span>
                          {isSelected && <Check className="w-4 h-4 text-primary ml-auto" />}
                        </div>
                      </motion.button>
                    )
                  })}
                </div>
                <p className="text-sm text-muted-foreground">
                  Selected: {selectedHabits.length} habits
                </p>
              </Card>
            )}

            {/* Step 3: Complete */}
            {step === 3 && (
              <Card className="p-8 text-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring" }}
                  className="w-24 h-24 bg-secondary rounded-full flex items-center justify-center mx-auto mb-6"
                >
                  <Check className="w-12 h-12 text-secondary-foreground" />
                </motion.div>
                <h2 className="text-2xl font-bold text-foreground mb-4">You&apos;re all set, {name}!</h2>
                <p className="text-muted-foreground mb-6">
                  We&apos;ll check in with you daily about your habits. 
                  Based on what you share, we&apos;ll guide you to the right space for your mood.
                </p>
                <div className="bg-muted/50 rounded-xl p-4 mb-6">
                  <p className="text-sm font-medium text-foreground mb-2">Your tracked habits:</p>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {selectedHabits.map(habit => (
                      <span key={habit.id} className="bg-background px-3 py-1 rounded-full text-sm">
                        {habit.icon} {habit.name}
                      </span>
                    ))}
                  </div>
                </div>
              </Card>
            )}
          </motion.div>
        </AnimatePresence>

        {/* Navigation */}
        <div className="flex justify-between mt-6">
          <Button
            variant="ghost"
            onClick={() => setStep(s => s - 1)}
            disabled={step === 0}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" /> Back
          </Button>
          
          {step < 3 ? (
            <Button
              onClick={() => setStep(s => s + 1)}
              disabled={!canProceed()}
              className="gap-2"
            >
              Continue <ArrowRight className="w-4 h-4" />
            </Button>
          ) : (
            <Button onClick={handleComplete} className="gap-2">
              Start My Journey <Sparkles className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}
