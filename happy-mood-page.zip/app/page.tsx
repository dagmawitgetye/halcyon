"use client"

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useApp } from '@/lib/context'
import { motion } from 'framer-motion'
import { Sparkles, Heart, Users, Shield, ArrowRight, Brain, Calendar, MessageCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import Link from 'next/link'

export default function HomePage() {
  const router = useRouter()
  const { isOnboarded, user } = useApp()

  useEffect(() => {
    if (isOnboarded && user) {
      router.push('/mood/happy')
    }
  }, [isOnboarded, user, router])

  const features = [
    {
      icon: Brain,
      title: "Behavioral Insights",
      description: "We learn your normal habits and detect when something feels different"
    },
    {
      icon: MessageCircle,
      title: "Personalized Chat",
      description: "Daily conversations tailored to your activities - like talking to a friend"
    },
    {
      icon: Calendar,
      title: "Mood Tracking",
      description: "Automatic mood detection based on your daily patterns and behaviors"
    },
    {
      icon: Users,
      title: "Counselor Support",
      description: "Connect with verified volunteer counselors when you need someone to talk to"
    },
  ]

  return (
    <main className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-secondary/10">
      {/* Hero */}
      <section className="container mx-auto px-4 pt-20 pb-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-3xl mx-auto"
        >
          <div className="inline-flex items-center gap-2 bg-primary/10 px-4 py-2 rounded-full mb-6">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">Your Wellness Companion</span>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 text-balance">
            Understand Yourself Better, <span className="text-primary">Every Day</span>
          </h1>
          
          <p className="text-lg text-muted-foreground mb-8 text-pretty">
            MindfulMe learns your daily habits and creates a personal space for reflection. 
            Whether you&apos;re feeling great or need support, we&apos;re here for you.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="gap-2" asChild>
              <Link href="/onboarding">
                Get Started <ArrowRight className="w-4 h-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="gap-2" asChild>
              <Link href="/counselor/register">
                <Heart className="w-4 h-4" /> Become a Volunteer Counselor
              </Link>
            </Button>
          </div>
        </motion.div>
      </section>

      {/* Features */}
      <section className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="p-6 h-full hover:shadow-lg transition-shadow">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-2xl font-bold text-center text-foreground mb-12">How It Works</h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          {[
            { step: "1", title: "Share Your Habits", desc: "Tell us about your normal daily activities - reading, exercise, socializing, etc." },
            { step: "2", title: "Daily Check-ins", desc: "We ask about your day based on YOUR habits. Did you read today? How was your walk?" },
            { step: "3", title: "Personalized Support", desc: "Based on your patterns, we guide you to the right space and connect you with help if needed." },
          ].map((item, i) => (
            <motion.div
              key={item.step}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + i * 0.1 }}
              className="text-center"
            >
              <div className="w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center mx-auto mb-4 font-bold text-lg">
                {item.step}
              </div>
              <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
              <p className="text-sm text-muted-foreground">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Counselor CTA */}
      <section className="container mx-auto px-4 py-16">
        <Card className="p-8 md:p-12 bg-gradient-to-r from-secondary/20 to-primary/20 border-0">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="flex-1">
              <div className="inline-flex items-center gap-2 bg-background/80 px-3 py-1 rounded-full mb-4">
                <Shield className="w-4 h-4 text-primary" />
                <span className="text-xs font-medium">Verified Counselors</span>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                Want to Help Others?
              </h2>
              <p className="text-muted-foreground mb-6">
                Join our community of verified volunteer counselors. Share your expertise, 
                support those in need, and make a real difference in people&apos;s lives.
              </p>
              <Button asChild>
                <Link href="/counselor/register">
                  Apply to Volunteer <ArrowRight className="w-4 h-4 ml-2" />
                </Link>
              </Button>
            </div>
            <div className="flex-shrink-0">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-background/80 p-4 rounded-xl text-center">
                  <div className="text-2xl font-bold text-primary">500+</div>
                  <div className="text-xs text-muted-foreground">Counselors</div>
                </div>
                <div className="bg-background/80 p-4 rounded-xl text-center">
                  <div className="text-2xl font-bold text-primary">10k+</div>
                  <div className="text-xs text-muted-foreground">Sessions</div>
                </div>
                <div className="bg-background/80 p-4 rounded-xl text-center">
                  <div className="text-2xl font-bold text-primary">4.9</div>
                  <div className="text-xs text-muted-foreground">Rating</div>
                </div>
                <div className="bg-background/80 p-4 rounded-xl text-center">
                  <div className="text-2xl font-bold text-primary">24/7</div>
                  <div className="text-xs text-muted-foreground">Available</div>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground">
            MindfulMe - Your personal wellness companion
          </p>
        </div>
      </footer>
    </main>
  )
}
