"use client"

import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { UserProfile, DailyCheckin, MoodType, UserHabit, DEFAULT_HABITS } from '@/lib/types'

interface AppContextType {
  user: UserProfile | null
  setUser: (user: UserProfile | null) => void
  checkins: DailyCheckin[]
  addCheckin: (checkin: DailyCheckin) => void
  currentMood: MoodType
  setCurrentMood: (mood: MoodType) => void
  isOnboarded: boolean
  completeOnboarding: (name: string, habits: UserHabit[]) => void
  updateStreak: () => void
}

const AppContext = createContext<AppContextType | undefined>(undefined)

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null)
  const [checkins, setCheckins] = useState<DailyCheckin[]>([])
  const [currentMood, setCurrentMood] = useState<MoodType>('neutral')
  const [isOnboarded, setIsOnboarded] = useState(false)

  useEffect(() => {
    // Load from localStorage on mount
    const savedUser = localStorage.getItem('mindful_user')
    const savedCheckins = localStorage.getItem('mindful_checkins')
    const savedOnboarded = localStorage.getItem('mindful_onboarded')
    
    if (savedUser) setUser(JSON.parse(savedUser))
    if (savedCheckins) setCheckins(JSON.parse(savedCheckins))
    if (savedOnboarded === 'true') setIsOnboarded(true)
  }, [])

  useEffect(() => {
    if (user) localStorage.setItem('mindful_user', JSON.stringify(user))
  }, [user])

  useEffect(() => {
    if (checkins.length > 0) localStorage.setItem('mindful_checkins', JSON.stringify(checkins))
  }, [checkins])

  const addCheckin = (checkin: DailyCheckin) => {
    setCheckins(prev => [...prev, checkin])
  }

  const completeOnboarding = (name: string, habits: UserHabit[]) => {
    const newUser: UserProfile = {
      id: crypto.randomUUID(),
      email: '',
      name,
      habits,
      current_mood: 'neutral',
      streak_days: 0,
      total_checkins: 0,
      joined_at: new Date().toISOString(),
    }
    setUser(newUser)
    setIsOnboarded(true)
    localStorage.setItem('mindful_onboarded', 'true')
  }

  const updateStreak = () => {
    if (!user) return
    
    const today = new Date().toDateString()
    const lastCheckin = user.last_checkin ? new Date(user.last_checkin).toDateString() : null
    
    if (lastCheckin === today) return // Already checked in today
    
    const yesterday = new Date()
    yesterday.setDate(yesterday.getDate() - 1)
    
    const newStreak = lastCheckin === yesterday.toDateString() 
      ? user.streak_days + 1 
      : 1
    
    setUser({
      ...user,
      streak_days: newStreak,
      total_checkins: user.total_checkins + 1,
      last_checkin: new Date().toISOString(),
    })
  }

  return (
    <AppContext.Provider value={{
      user,
      setUser,
      checkins,
      addCheckin,
      currentMood,
      setCurrentMood,
      isOnboarded,
      completeOnboarding,
      updateStreak,
    }}>
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const context = useContext(AppContext)
  if (!context) {
    throw new Error('useApp must be used within an AppProvider')
  }
  return context
}
