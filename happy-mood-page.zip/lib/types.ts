export type MoodType = 'happy' | 'stressed' | 'lonely' | 'neutral'

export interface UserHabit {
  id: string
  name: string
  icon: string
  category: 'physical' | 'mental' | 'social' | 'creative' | 'productivity'
  normalDuration?: number // in minutes
  normalFrequency?: 'daily' | 'weekly' | 'occasionally'
}

export interface UserProfile {
  id: string
  email: string
  name: string
  avatar_url?: string
  habits: UserHabit[]
  current_mood: MoodType
  streak_days: number
  total_checkins: number
  joined_at: string
  last_checkin?: string
}

export interface DailyCheckin {
  id: string
  user_id: string
  date: string
  mood: MoodType
  screen_time_minutes: number
  habits_completed: string[]
  journal_entry?: string
  ai_insights?: string
  created_at: string
}

export interface Counselor {
  id: string
  user_id: string
  full_name: string
  email: string
  phone?: string
  education_level: string
  field_of_study: string
  workplace: string
  experience_years: number
  why_counsel: string
  certifications: string[]
  certificate_urls: string[]
  specializations: string[]
  availability: CounselorAvailability[]
  is_verified: boolean
  is_active: boolean
  rating: number
  total_sessions: number
  created_at: string
}

export interface CounselorAvailability {
  day: 'monday' | 'tuesday' | 'wednesday' | 'thursday' | 'friday' | 'saturday' | 'sunday'
  start_time: string
  end_time: string
}

export interface CounselorSession {
  id: string
  user_id: string
  counselor_id: string
  scheduled_at: string
  duration_minutes: number
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled'
  notes?: string
  user_mood_before?: MoodType
  user_mood_after?: MoodType
  created_at: string
}

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: string
}

export const DEFAULT_HABITS: UserHabit[] = [
  { id: 'reading', name: 'Reading', icon: '📚', category: 'mental', normalDuration: 30, normalFrequency: 'daily' },
  { id: 'exercise', name: 'Exercise', icon: '🏃', category: 'physical', normalDuration: 45, normalFrequency: 'daily' },
  { id: 'meditation', name: 'Meditation', icon: '🧘', category: 'mental', normalDuration: 15, normalFrequency: 'daily' },
  { id: 'walking', name: 'Walking', icon: '🚶', category: 'physical', normalDuration: 30, normalFrequency: 'daily' },
  { id: 'socializing', name: 'Socializing', icon: '👥', category: 'social', normalDuration: 60, normalFrequency: 'daily' },
  { id: 'cooking', name: 'Cooking', icon: '🍳', category: 'creative', normalDuration: 45, normalFrequency: 'daily' },
  { id: 'music', name: 'Playing Music', icon: '🎵', category: 'creative', normalDuration: 30, normalFrequency: 'occasionally' },
  { id: 'journaling', name: 'Journaling', icon: '✍️', category: 'mental', normalDuration: 15, normalFrequency: 'daily' },
  { id: 'gaming', name: 'Gaming', icon: '🎮', category: 'creative', normalDuration: 60, normalFrequency: 'occasionally' },
  { id: 'coding', name: 'Coding', icon: '💻', category: 'productivity', normalDuration: 120, normalFrequency: 'daily' },
  { id: 'art', name: 'Art/Drawing', icon: '🎨', category: 'creative', normalDuration: 45, normalFrequency: 'occasionally' },
  { id: 'yoga', name: 'Yoga', icon: '🧘‍♀️', category: 'physical', normalDuration: 30, normalFrequency: 'daily' },
]
