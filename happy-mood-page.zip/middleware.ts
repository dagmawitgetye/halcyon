import { type NextRequest, NextResponse } from 'next/server'

export async function middleware(request: NextRequest) {
  // For now, just pass through all requests
  // When Supabase is connected, this will handle session management
  return NextResponse.next()
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}
